import { Controller } from '@nestjs/common';

@Controller('tareas')
export class TareasController {}
